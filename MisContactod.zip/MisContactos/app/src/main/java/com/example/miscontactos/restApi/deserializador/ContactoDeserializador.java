package com.example.miscontactos.restApi.deserializador;

import com.example.miscontactos.pojo.Contacto;
import com.example.miscontactos.restApi.JsonKeys;
import com.example.miscontactos.restApi.model.ContactoResponse;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class ContactoDeserializador implements JsonDeserializer<ContactoResponse> {

    @Override
    public ContactoResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        //creamos el objeto para deserializar el gson
        Gson gson = new Gson();
        ContactoResponse contactoResponse = gson.fromJson(json, ContactoResponse.class);
        //creamos el objeto de tipo arreglo para el gson
        JsonArray contactoResponseData = json.getAsJsonObject().getAsJsonArray(JsonKeys.MEDIA_RESPONSE_ARRAY);
        contactoResponse.setContactos(deserializarContactoDeJson(contactoResponseData));
        //retornamos el deserializador
        return contactoResponse;
    }
    private ArrayList<Contacto> deserializarContactoDeJson(JsonArray contactoResponseData){
        //array para devolver los datos
        ArrayList<Contacto> contactos = new ArrayList<>();
        for (int i = 0; i <contactoResponseData.size()  ; i++) {
            JsonObject contactoResponseDataObject = contactoResponseData.get(i).getAsJsonObject();
            JsonObject userJson = contactoResponseDataObject.getAsJsonObject(JsonKeys.MEDIA_RESPONSE_ARRAY);
            JsonObject owner = contactoResponseDataObject.getAsJsonObject("owner");
            String id = owner.get(JsonKeys.USER_ID).getAsString();
            //String nombreCompleto = userJson.get(JsonKeys.USER_FULLNAME).getAsString();

            JsonObject imageJson = contactoResponseDataObject.getAsJsonObject(JsonKeys.MEDIA_RESPONSE_ARRAY);
            //JsonObject stdResolutionJson = imageJson.getAsJsonObject(JsonKeys.MEDIA_STANDARD_RESOLUTION);
            String urlFoto = imageJson.get(JsonKeys.MEDIA_URL).getAsString();

            JsonObject likesJson = contactoResponseDataObject.getAsJsonObject(JsonKeys.MEDIA_RESPONSE_ARRAY);
            int likes = likesJson.get(JsonKeys.MEDIA_LIKES_COUNT).getAsInt();

            //retornamos los arrays
            Contacto contactoActual = new Contacto();
            contactoActual.setId(id);
            //contactoActual.setNombreCompleto(nombreCompleto);
            contactoActual.setUrlFoto(urlFoto);
            contactoActual.setLikes(likes);
            //adicionamos al arreglo contactos
            contactos.add(contactoActual);
        }
        return contactos;//retornamos el arraylist
    }
}
