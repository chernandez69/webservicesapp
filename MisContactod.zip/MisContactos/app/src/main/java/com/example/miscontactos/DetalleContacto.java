package com.example.miscontactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetalleContacto extends AppCompatActivity {
   // private TextView tvNombre;
    //private TextView tvTelefono;
    //private TextView tvEmail;
    private static final String KEY_EXTRA_URL = "url";
    private static final String KEY_EXTRA_LIKES = "like";
    private ImageView imgFotoDetalle;
    private TextView tvLikesDetalle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_contacto_foto);
        //atrapamos los datos del activity anterior
        Bundle parametros   = getIntent().getExtras();

        String url          = parametros.getString(KEY_EXTRA_URL);
        int likes           = parametros.getInt(KEY_EXTRA_LIKES);

        tvLikesDetalle   = (TextView) findViewById(R.id.tvlikesDetalle);
        imgFotoDetalle   = (ImageView) findViewById(R.id.imgFotoDetalle);
        //cargamos en los text vew datos
        tvLikesDetalle.setText(String.valueOf(likes));
        //cargamos la foto del contacto
        Picasso.get()
                .load(url)
                .placeholder(R.drawable.emailico)
                .into(imgFotoDetalle);

    }

    /*public void llamar(View v){
        String telefono = tvTelefono.getText().toString();
        startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telefono)));
    }*/

    /*public void enviarEmail(View v){
        String email = tvEmail.getText().toString();
        Intent emailIntent = new Intent((Intent.ACTION_SEND));
        emailIntent.setData(Uri.parse("mailto:")).putExtra(Intent.EXTRA_EMAIL, email);
        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent,"Email"));
    }*/

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
         if (keyCode==KeyEvent.KEYCODE_BACK){
             Intent intent = new Intent(DetalleContacto.this, MainActivity.class);
             startActivity(intent);
         }
        return super.onKeyDown(keyCode, event);
    }
}