package com.example.miscontactos.vista.fragment;

import com.example.miscontactos.adapter.ContactoAdaptador;
import com.example.miscontactos.pojo.Contacto;

import java.util.ArrayList;

public interface iRecyclerViewFragmentView {
    //metodos para generar el layout  el arraylist contactos
    //inicar el adaptador
    public void genrarLinearLayoutVertical();
    public void genrarGridLayout();
    public ContactoAdaptador crearAdaptador(ArrayList<Contacto> contactos);
    public void inicializarAdaptadorRV(ContactoAdaptador adaptador);

    
}
