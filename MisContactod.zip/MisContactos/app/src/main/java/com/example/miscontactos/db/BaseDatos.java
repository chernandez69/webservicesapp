package com.example.miscontactos.db;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.miscontactos.pojo.Contacto;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private Context context;
    public BaseDatos(Context context) {
        //definimos nombre y version db
        super(context,ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context=context;
    }
    //heredhdhddhdh

    @Override
    public void onCreate(SQLiteDatabase db) {
        //creamos la estuctura de la base de datos tablas, etc
        String queryCrearTablaContacto="CREATE TABLE "+ ConstantesBaseDatos.TABLE_CONTACTS + "("+
                                        ConstantesBaseDatos.TABLE_CONTACTS_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                        ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE   + " TEXT, "+
                                        ConstantesBaseDatos.TABLE_CONTACTS_TELEFONO + " TEXT, "+
                                        ConstantesBaseDatos.TABLE_CONTACTS_EMAIL    + " TEXT, "+
                                        ConstantesBaseDatos.TABLE_CONTACTS_FOTO     + " INTEGER"+
                                       ")";
        String queryCrearTablaLikesContacto = "CREATE TABLE "+ ConstantesBaseDatos.TABLE_LIKES_CONTACT + "("+
                                            ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                            ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_CONTACTO + " INTEGER, "+
                                            ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES + " INTEGER, "+
                                            "FOREIGN KEY(" + ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_CONTACTO +") " +
                                            "REFERENCES "+ ConstantesBaseDatos.TABLE_CONTACTS + "("+ConstantesBaseDatos.TABLE_CONTACTS_ID+")"+
                                            ")";
        //ejecutamos el query para crear la bd
        db.execSQL(queryCrearTablaContacto);
        //cremos la estructura de la tabla contacto_likes
        db.execSQL(queryCrearTablaLikesContacto);
    }//oncreate

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //afecta a la base de datos la elimina si exists
        db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_LIKES_CONTACT);
        //vuelve a crear la bd
        onCreate(db);
    }//on upgrade

    public ArrayList<Contacto> obtenerTodosLosContactos(){
        ArrayList<Contacto> contactos = new ArrayList<>();
        //ejecutamos el query para los contactos
        String query = "SELECT * FROM " + ConstantesBaseDatos.TABLE_CONTACTS;
        //abrimos la bd
        SQLiteDatabase db = this.getWritableDatabase();
        //creamos un cursor para recorre los datos
        Cursor regitros = db.rawQuery(query, null);
        //recorremos los registros con while
        while (regitros.moveToNext()){
          /*  Contacto contactoActual = new Contacto();
            contactoActual.setId(regitros.getInt(0));
            contactoActual.setNombre(regitros.getString(1));
            contactoActual.setTelefono(regitros.getString(2));
            contactoActual.setEmail(regitros.getString(3));
            contactoActual.setFoto(regitros.getInt(4));
            //traemos los likes de la bd likes al inicia la app
            String queryLikes = "SELECT COUNT("+ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES+") as likes "+
                                " FROM " + ConstantesBaseDatos.TABLE_LIKES_CONTACT +
                                " WHERE " + ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_CONTACTO + "=" + contactoActual.getId();
            Cursor registrosLikes = db.rawQuery(queryLikes, null);
            if (registrosLikes.moveToNext()){
                contactoActual.setLikes(registrosLikes.getInt(0));
            }else{
                contactoActual.setLikes(0);
            }

            contactos.add(contactoActual);*/
        }//while
        db.close();//cerrar luego de query
        return contactos;
    }//

    //metodo insertar datos
    public void insertarContacto(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        //el metodo value hace referencia al campo y valor
        db.insert(ConstantesBaseDatos.TABLE_CONTACTS, null, contentValues);
        db.close();
    }

    public void insertarLikeContacto(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        //el metodo value hace referencia al campo y valor
        db.insert(ConstantesBaseDatos.TABLE_LIKES_CONTACT, null, contentValues);
        db.close();
    }//insertar like

    public int obtenerLikesContacto(Contacto contacto){
        //obtener la suma de los likes de la bd
        int likes =0;
        String query = "SELECT COUNT("+ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES+")"+
                " FROM "+ ConstantesBaseDatos.TABLE_LIKES_CONTACT +
                " WHERE "+ ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_CONTACTO + "="
                + contacto.getId();
        SQLiteDatabase db = this.getWritableDatabase();
        //recuperamos el query con un cursor
        Cursor registros= db.rawQuery(query, null);
        if(registros.moveToNext()){
            //recuperamos los registros
            likes=registros.getInt(0);
        }//if
        db.close();
        return likes;

    }
}
