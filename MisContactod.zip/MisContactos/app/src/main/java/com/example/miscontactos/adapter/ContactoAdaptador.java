package com.example.miscontactos.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miscontactos.db.ConstructorContactos;
import com.example.miscontactos.pojo.Contacto;
import com.example.miscontactos.DetalleContacto;
import com.example.miscontactos.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ContactoAdaptador extends RecyclerView.Adapter<ContactoAdaptador.ContactoViewHolder>{
    ArrayList<Contacto> contactos;
    Activity activity;
    public ContactoAdaptador(ArrayList<Contacto> contactos, Activity activity){
        this.contactos = contactos;
        this.activity = activity;
    }


    //inflar el layout y lo pasara al viewholder para que obtenga los views
    @NonNull
    @Override
    public ContactoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_grid_contacto, parent, false);
        return new ContactoViewHolder(v) ;//pasamos el layout creado como un view
    }
    //asocia cada elemento de la vista con cada view
    @Override
    public void onBindViewHolder(@NonNull final ContactoViewHolder contactoViewHolder, int position) {
        //seteamos cada uno de los elementos que trae la lista
        final Contacto contacto = contactos.get(position);
        //contactoViewHolder.imgFoto.setImageResource(contacto.getUrlFoto());//acceder al get foto
        //cargamos la foto con la libreria picasso
        Picasso.get()
                .load(contacto.getUrlFoto())
                .placeholder(R.drawable.emailico)
                .into(contactoViewHolder.imgFoto);
        //contactoViewHolder.tvNombreCV.setText(contacto.getNombre());
        //contactoViewHolder.tvTelefonoCV.setText(contacto.getTelefono());
        contactoViewHolder.tvlikes.setText(Integer.toString(contacto.getLikes()));

        /*contactoViewHolder.btnlike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//evento del boton like
                Toast.makeText(activity, "Diste like a: " + contacto.getNombre(),Toast.LENGTH_SHORT).show();
                //llamamos al constructor para registrar los likes
                ConstructorContactos constructorContactos = new ConstructorContactos(activity);
                constructorContactos.darLikeContacto(contacto);
                //mostramos los likes en el textview del viewholder
                contactoViewHolder.tvlikes.setText(Integer.toString(constructorContactos.obtenerLikesContacto(contacto)));
            }//onclik
        });*/
        contactoViewHolder.imgFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//toast muestra nombre al dar click en la foto
                //Toast.makeText(activity, contacto.getNombre(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(activity, DetalleContacto.class);
                intent.putExtra("url", contacto.getUrlFoto());
                intent.putExtra("like", contacto.getLikes());
               // intent.putExtra("email", contacto.getEmail());
                //intent.putExtra("likes", contacto.getLikes());
                activity.startActivity(intent);
                //finish();
            }
        });
    }

    @Override
    public int getItemCount() {//cantidad de elementos de la lista
        return contactos.size();
    }

    public static class ContactoViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgFoto;
        //private TextView tvNombreCV;
        //private TextView tvTelefonoCV;
        //private ImageButton btnlike;
        private TextView tvlikes;

        public ContactoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFoto      = (ImageView) itemView.findViewById(R.id.imgfoto);
            //tvNombreCV   = (TextView) itemView.findViewById(R.id.tvNombreCV);
            //tvTelefonoCV = (TextView) itemView.findViewById(R.id.tvTelefonoCV);
            tvlikes      = (TextView) itemView.findViewById(R.id.tvlikes);
            //btnlike      = (ImageButton) itemView.findViewById(R.id.btnlike);
        }
    }
}
