package com.example.miscontactos.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.miscontactos.R;
import com.example.miscontactos.pojo.Contacto;

import java.util.ArrayList;

public class ConstructorContactos {
    private static final int LIKE = 1;
    private Context context;

    public ConstructorContactos(Context context) {
        this.context=context;
    }

    public ArrayList<Contacto> obtenerDatos(){
        //cargamos datos dummie antes bd
        /*ArrayList<Contacto> contactos = new ArrayList<Contacto>();//array objeto contactos
        contactos.add(new Contacto(R.drawable.ic1,"Carlos Hernandez", "555777","cahernandezg1@gmail.com",2));
        contactos.add(new Contacto(R.drawable.ic2,"Juan Perez", "77779999","j.perez@gmail.com", 3));
        contactos.add(new Contacto(R.drawable.ic3,"Olga Barón", "6667778", "o.baron@hotmail.com", 4));
        contactos.add(new Contacto(R.drawable.ic4,"Magali Suarez", "44555777","m.suarez@yahoo.es", 5));
        return contactos;
        */
        //instanciamos la clase base datos para traer los contactos de la fuente
        BaseDatos db = new BaseDatos(context);
        insertarTresContacto(db);
        return db.obtenerTodosLosContactos();
    }
//voy aqui

    public void insertarTresContacto(BaseDatos db){
        //agregar contacto a la bd, genramos objeto content value
        ContentValues contentValues = new ContentValues();
        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE,"Carlos Hernandez");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_TELEFONO,"555777");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_EMAIL,"cahernandezg1@gmail.com");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_FOTO, R.drawable.ic1 );
        //llamamos al metodo insertarcontacto
        db.insertarContacto(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE,"Juan Perez");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_TELEFONO,"77779999");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_EMAIL,"j.perez@gmail.com");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_FOTO, R.drawable.ic2 );
        //llamamos al metodo insertarcontacto
        db.insertarContacto(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE,"Olga Baron");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_TELEFONO,"6667778");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_EMAIL,"o.baron@hotmail.com");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_FOTO, R.drawable.ic3 );
        //llamamos al metodo insertarcontacto
        db.insertarContacto(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE,"Magali SUarez");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_TELEFONO,"44555777");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_EMAIL,"m.suarez@yahoo.es");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_FOTO, R.drawable.ic4 );
        //llamamos al metodo insertarcontacto
        db.insertarContacto(contentValues);
    }//insertartrescontactos

    public void darLikeContacto(Contacto contacto){
        //metodo para registrar los likes en la bd
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_CONTACTO,contacto.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES, LIKE);
        //invocamos el metodo insertar para likes
        db.insertarLikeContacto(contentValues);
    }//dar like

    public int obtenerLikesContacto(Contacto contacto){
        //metodo para traer los likes de la bd
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesContacto(contacto);
    }//obtenerlikes
}
