package com.example.miscontactos.restApi.adapter;

import com.example.miscontactos.restApi.ConstantesRestApi;
import com.example.miscontactos.restApi.EndpointsApi;
import com.example.miscontactos.restApi.deserializador.ContactoDeserializador;
import com.example.miscontactos.restApi.model.ContactoResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestApiAdapter {
    //devolver objetos de endpoit
    public EndpointsApi establecerConexionRestApiInstagram(Gson gson){
        Retrofit retrofit= new Retrofit.Builder()
                .baseUrl(ConstantesRestApi.ROOT_URL)
                //deserializacion json
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        //retornamos los objetos endpoint
        return retrofit.create(EndpointsApi.class);
    }
    public Gson construyeGsonDeserializadorMediaRecent(){
        GsonBuilder gsonBuilder = new GsonBuilder();
        //asocia lo que deserialize al objeto reponser
        gsonBuilder.registerTypeAdapter(ContactoResponse.class, new ContactoDeserializador());
        //creamos la asociacion
       return gsonBuilder.create();
    }
}
