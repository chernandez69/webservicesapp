package com.example.miscontactos.presentador;

public interface iRecyclerViewFragmentPresenter {
    //interface para obtener y presentar los datos en recyclerview
    public void obtenerContactosBaseDatos();
    void obtenerMediosRecientes();
    public void mostrarContactosRV();
}
