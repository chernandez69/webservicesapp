package com.example.miscontactos.presentador;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.example.miscontactos.restApi.EndpointsApi;
import com.example.miscontactos.restApi.adapter.RestApiAdapter;
import com.example.miscontactos.restApi.model.ContactoResponse;
import com.example.miscontactos.vista.fragment.iRecyclerViewFragmentView;
import com.example.miscontactos.db.ConstructorContactos;
import com.example.miscontactos.pojo.Contacto;
import com.google.gson.Gson;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecyclerViewFragmentPresenter implements iRecyclerViewFragmentPresenter{
    private iRecyclerViewFragmentView iRecyclerViewFragmentView;
    private Context context;
    private ConstructorContactos constructorContactos;
    private ArrayList<Contacto> contactos;

    public RecyclerViewFragmentPresenter(iRecyclerViewFragmentView iRecyclerViewFragmentView, Context context){
        this.iRecyclerViewFragmentView=iRecyclerViewFragmentView;
        this.context = context;
        //obtenerContactosBaseDatos();
        obtenerMediosRecientes();
    }


    @Override
    public void obtenerContactosBaseDatos() {
        //traer los datos
        constructorContactos = new ConstructorContactos(context);
        contactos = constructorContactos.obtenerDatos();
        //llamamos al mostrar contactos en el RV
        mostrarContactosRV();
    }

    @Override
    public void obtenerMediosRecientes() {
        //obtener fotos y conectar con el api instagram
        RestApiAdapter restApiAdapter = new RestApiAdapter();
        Gson gsonMediaRecent = restApiAdapter.construyeGsonDeserializadorMediaRecent();
        EndpointsApi endpointsApi = restApiAdapter.establecerConexionRestApiInstagram(gsonMediaRecent);
        //asignamos al response el endpoit
        Call<ContactoResponse> contactoResponseCall =endpointsApi.getRecentMedia();
        //controlar la respuesta
        contactoResponseCall.enqueue(new Callback<ContactoResponse>() {
            @Override
            public void onResponse(Call<ContactoResponse> call, Response<ContactoResponse> response) {
                ContactoResponse contactoResponse = response.body();
                contactos = contactoResponse.getContactos();
                //mostramos los conntactos en el RV
                mostrarContactosRV();
            }

            @Override
            public void onFailure(Call<ContactoResponse> call, Throwable t) {
                Toast.makeText(context, "Fallo la conexion", Toast.LENGTH_LONG).show();
                Log.e("Fallo la conexion", t.toString());
            }
        });

    }

    @Override
    public void mostrarContactosRV() {
        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(contactos));
        iRecyclerViewFragmentView.genrarGridLayout();
    }
}
