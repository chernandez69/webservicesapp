package com.example.miscontactos.restApi;

public final class ConstantesRestApi {
    //https://graph.facebook.com/v9.0/17841445058264095/media?fields=id,media_type,media_url,like_count,owner,timestamp&access_token=
    // EAAETIQcgMZAABAH3zmrAMaPFZAjKwG99LOUXElWvmfFucwtQ31PTzz42hIY9m4ZCBxSQXjNNmqHMtFbhZCa1C0xS4Lor4fjkg75JeuSyDjOFHIg3Jg2qZBOp2IrGZAwAIBb0RBfvOprb6C3tiVh7170Lx8kDv1QV0ZD
    //url base https://api.instagram.com/v1
    public static final String VERSION="/v9.0/";
    public static final String ROOT_URL="https://graph.facebook.com" + VERSION;
    public static final String ACCES_TOKEN="EAAETIQcgMZAABAH3zmrAMaPFZAjKwG99LOUXElWvmfFucwtQ31PTzz42hIY9m4ZCBxSQXjNNmqHMtFbhZCa1C0xS4Lor4fjkg75JeuSyDjOFHIg3Jg2qZBOp2IrGZAwAIBb0RBfvOprb6C3tiVh7170Lx8kDv1QV0ZD";
    public static final String KEY_ACCES_TOKEN="&access_token=";
    public static final String KEY_GET_RECENT_MEDIA_USER="17841445058264095/media?fields=id,media_url";
    public static final String URL_GET_RECENT_MEDIA_USER="17841445058264095/media?fields=id,media_type,media_url,like_count,owner,timestamp&access_token=EAAETIQcgMZAABAH3zmrAMaPFZAjKwG99LOUXElWvmfFucwtQ31PTzz42hIY9m4ZCBxSQXjNNmqHMtFbhZCa1C0xS4Lor4fjkg75JeuSyDjOFHIg3Jg2qZBOp2IrGZAwAIBb0RBfvOprb6C3tiVh7170Lx8kDv1QV0ZD";
}

