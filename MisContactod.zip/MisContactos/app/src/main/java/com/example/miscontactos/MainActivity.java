package com.example.miscontactos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.miscontactos.adapter.PageAdapter;
import com.example.miscontactos.vista.fragment.PerfilFragment;
import com.example.miscontactos.vista.fragment.RecyclerViewFragment;
import com.example.miscontactos.pojo.Contacto;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Contacto> contactos;
    //declaramos el reciclerview
    private RecyclerView listaContactos;
    private androidx.appcompat.widget.Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //creamos los componentes
        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        //llamamos al metodo para crear los viewpager
        setUpViewPager();

        //validadmos el toolbar qe no sea nulo
        if(toolbar != null){
            setSupportActionBar(toolbar);
        }


        /*
        androidx.appcompat.widget.Toolbar miActionBar = findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);//para que se vea bien en todas las pantalla
        //instanciamos el reciclerview
        listaContactos = (RecyclerView) findViewById(R.id.rvContactos);
        //creamos un linearlayout manager para las listas
        //LinearLayoutManager llm = new LinearLayoutManager(this);
        //llm.setOrientation(LinearLayoutManager.VERTICAL);
        LinearLayoutManager glm = new LinearLayoutManager(this);
        glm.setOrientation(LinearLayoutManager.VERTICAL);
        listaContactos.setLayoutManager(glm);//hacemos que el reciclerview se porte como linearL

        inicializarListaContactos();
        inicializaAdaptador();*/
      /*  //creamos listview para la lista de contactos y su adapter para la carga
        ArrayList<String> nombresContacto = new ArrayList<>();//inicilizamos el array list
        for (Contacto contacto:contactos) {//llenamos el arraylist con los nombres
            nombresContacto.add(contacto.getNombre());
        }
      */
        /*
        //creacion del listview y su adapter
        ListView lstContactos = (ListView) findViewById(R.id.lstContactos);
        lstContactos.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nombresContacto));
        //creamos el intent y el click listener para el listview
        lstContactos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetalleContacto.class);
                intent.putExtra(getResources().getString(R.string.pnombre),contactos.get(position).getNombre());
                intent.putExtra(getResources().getString(R.string.ptelefono), contactos.get(position).getTelefono());
                intent.putExtra(getResources().getString(R.string.pemail),contactos.get(position).getEmail());
                startActivity(intent);
                finish();
            }
        });
       */
    }

    //metodo para iniciar y llenar los fragments
    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(new RecyclerViewFragment());
        fragments.add(new PerfilFragment());
        return fragments;
    }
    private void setUpViewPager(){
     //agregamos el fragment al adapter
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(),2, agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_like);
        tabLayout.getTabAt(1).setIcon(R.drawable.emailico);

    }

}