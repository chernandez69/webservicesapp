package com.example.miscontactos.vista.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miscontactos.R;
import com.example.miscontactos.adapter.ContactoAdaptador;
import com.example.miscontactos.pojo.Contacto;
import com.example.miscontactos.presentador.RecyclerViewFragmentPresenter;
import com.example.miscontactos.presentador.iRecyclerViewFragmentPresenter;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment implements iRecyclerViewFragmentView{
    private ArrayList<Contacto> contactos;
    private RecyclerView listaContactos;
    private iRecyclerViewFragmentPresenter presenter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //infllamos el fragment
        View v = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        //instanciamos el reciclerview
        listaContactos = (RecyclerView) v.findViewById(R.id.rvContactos);
        //instanciamos el presentador
        presenter = new RecyclerViewFragmentPresenter(this, getContext());
        return v;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }//oncreate


   /* public void inicializarListaContactos(){
        //cargar los datos
        contactos = new ArrayList<Contacto>();//array objeto contactos
        contactos.add(new Contacto(R.drawable.ic1,"Carlos Hernandez", "555777","cahernandezg1@gmail.com",0));
        contactos.add(new Contacto(R.drawable.ic2,"Juan Perez", "77779999","j.perez@gmail.com", 0));
        contactos.add(new Contacto(R.drawable.ic3,"Olga Barón", "6667778", "o.baron@hotmail.com", 0));
        contactos.add(new Contacto(R.drawable.ic4,"Magali Suarez", "44555777","m.suarez@yahoo.es", 0));
    }*/

    @Override
    public void genrarLinearLayoutVertical() {
        LinearLayoutManager glm = new LinearLayoutManager(getActivity());
        glm.setOrientation(LinearLayoutManager.VERTICAL);
        listaContactos.setLayoutManager(glm);//hacemos que el reciclerview se porte como linearL
    }

    @Override
    public void genrarGridLayout() {
        //generar las tarjetas en grid
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        listaContactos.setLayoutManager(gridLayoutManager);
    }

    @Override
    public ContactoAdaptador crearAdaptador(ArrayList<Contacto> contactos) {
       ContactoAdaptador adaptador = new ContactoAdaptador(contactos, getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(ContactoAdaptador adaptador) {
        listaContactos.setAdapter(adaptador);
    }
}
